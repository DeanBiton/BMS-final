// import Checkout from "../components/CreateEvent/Checkout"
// import Review from "../components/CreateEvent/Review"
// import NewEvent from "./Event"
export default function Test(){
    return(
        <></>
        // <Checkout/>
        // <NewEvent/>
    )
}